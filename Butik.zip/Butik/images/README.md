Mappe: /images
==============

I denne mappe kan du lægge de billeder, som din webside skal bruge.